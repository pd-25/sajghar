-- AlterTable
ALTER TABLE `productinquiry` MODIFY `message` TEXT NULL;
