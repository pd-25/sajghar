-- AlterTable
ALTER TABLE `product` ADD COLUMN `price` VARCHAR(191) NULL;
