import React from 'react'

const Contact = () => {
  return (
    <div>page</div>
  )
}

export default Contact